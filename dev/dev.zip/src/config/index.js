const Loading= 1
const userName='xiaoming';
const token='12345678';
export default
  {
    userName,//用户名字
    token,//用户token
    Loading
  }