<template>
  <div id="z_nav">
    <ul>
      <li v-for="(v, i) in $router.options.routes.slice(0, -2)" :key="i">
        <router-link :to="v.path" :class="v.name"
          ><span :class="['iconfont',v.meta.iconfont]"></span
          >{{ v.meta.znav }}</router-link
        >
      </li>
    </ul>
    <button @click="getNavLink">2323</button>
    <!-- <ul>
      <li>
        <router-link v-for="(v, i) in $router.options.routes" :key="i" :to="v.path">{{ v.meta.znav }}</router-link>
      </li>
    </ul> -->
  </div>
</template>
<script>
export default {
  name: "Znav",
  navlink: {},
  beforeMount() {
    this.getNavLink();

  },
  mounted() {
  },
  methods: {
    getNavLink() {
      console.log(this.$router.options.routes);

    },
  },
};
</script>
<style scoped>
ul {
  float: right;
}
li {
  float: left;
}
.icon-collect {
  font-size: 16pxpx;
  color: red;
}
</style>