<template>
  <div id="z_login">
    <div class="login">
      <h2>Login</h2>
      <!-- <div class="login_box" :model="ruleForm" :rules="rules" ref="ruleForm"> -->
      <!-- required就是不能为空 必须在css效果中有很大的作用 -->
      <!-- 可以简写为required -->
      <!-- <input class="input" type="text" required /><label>用户名</label> -->
      <!-- <el-input
          v-model="ruleForm.username"
          @focus="funf($event)"
          @blur="funb($event)"
          value="admin"
          prop="username"
          required
        ></el-input
        ><label>用户名</label>
      </div>
      <div class="login_box">
        <el-input
          v-model="ruleForm.password"
          @focus="funf($event)"
          @blur="funb($event)"
          show-password
          prop="password"
          required
        ></el-input
        ><label>密码</label> -->
      <!-- <input class="input" type="password" required="required" /><label>密码</label> -->
      <!-- </div> -->

      <!-- ------------- -->
      <el-form
        :model="ruleForm"
        :rules="rules"
        ref="ruleForm"
        label-width="100px"
        class="login_box"
      >
      <el-form-item label="用户名" prop="username">
        <el-input
          v-model="ruleForm.username"
          @focus="funf($event)"
          @blur="funb($event)"
        ></el-input
        >
        </el-form-item>
        <!-- <label class="usetie">用户名</label> -->
        <el-form-item label="密码" prop="password">
        <el-input
          v-model="ruleForm.password"
          @focus="funf($event)"
          @blur="funb($event)"
          show-password
        ></el-input
        ></el-form-item>
        <!-- <label class="passtie">密码</label> -->
      </el-form>
      <!-- ----------- -->

      <a href="javascript:void(0)" :plain="true" @click="zlogin('ruleForm')">
        登录
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </a>
    </div>
  </div>
</template>
<script>
import * as request from "@/utils/request.js";
import storage from '@/utils/storage.js'
export default {
  name: "Zlogin",
  data() {
    return {
      ruleForm: {
        username: "",
        password: ""
      },
      rules: {
        username: [
          { required: true, message: "请输入用户名", trigger: "blur" },
          { min: 3, max: 5, message: "长度在 3 到 5 个字符", trigger: "blur" },
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { min: 3, max: 6, message: "长度在 3 到 6 个字符", trigger: "blur" },
        ],
      },
    };
  },
  methods: {
    funf(event) {
      let finput = event.currentTarget.parentNode.parentNode.previousSibling;
        finput.style.color = "#03e9f4";
        finput.style.FontSize = "12px";
      switch (finput.innerHTML) {
        case "用户名":
          finput.style.top = "-24px";
          break;
        case "密码":
          finput.style.top = "66px";
          break;
        default:
        //   console.log("其他");
          break;
      }
    },
    funb(event) {
      if (!event.target.value) {
        let binput = event.currentTarget.parentNode.parentNode.previousSibling;
        binput.style.color = "#fff";
        binput.style.FontSize = "16px";
        switch (binput.innerHTML) {
          case "用户名":
            binput.style.top = "0";
            break;
          case "密码":
            binput.style.top = "92px";
            break;
          default:
            // console.log("其他");
            break;
        }
      }
    },
    zlogin(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          request
          .post(
            "https://www.fastmock.site/mock/c75410481f465870161a38a215fbbad9/test/logo",
            {
              username: this.ruleForm.username,
              password: this.ruleForm.password,
            }
          )
          .then((res) => {
            if (res.data.data.verifySuccess) {
              this.$message({
                showClose: true,
                message: "登录成功",
                type: "success",
              });
              storage.set("token",this.ruleForm.username)
              if (this.$route.query.redirect) {
              this.$router.push({ path: `${this.$route.query.redirect}` })
            } else {
              this.$router.push({ path: '/' })
            }
            } else {
              this.$message({
                showClose: true,
                message: "请检查您的账号&密码",
                type: "warning",
              });
            }
          })
          .catch((err) => {
            this.$message({
              showClose: true,
              message: "登录失败",
              type: "error",
            });
          });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert("submit!");
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
  },
};
</script>
<style>
.el-form-item__error{
    padding-top: 0 !important;
    top: 42px !important;
}
.el-form-item__label::before{
    content: '' !important;
    width: 0 !important;
}
.login_box .el-form-item__label{
    width: auto !important;
    position: absolute;
  left: 0;
  /* padding: 10px 0; */
  color: #fff;
  /* 这个属性的默认值是auto 默认是这个元素可以被点击 但是如果我们写了none 就是这个元素不能被点击 , 就好像它可见但是不能用 可望而不可即 */
  /* 这个就是两者的区别 */
  pointer-events: none;
  /* 加个过渡 */
  transition: all 0.5s;
}
.el-form-item:nth-of-type(1) .el-form-item__label{
    top:0;
}
.el-form-item:nth-of-type(2) .el-form-item__label{
    top:92px;
}
* {
  /* 初始化 清除页面元素的内外边距 */
  padding: 0;
  margin: 0;
  /* 盒子模型 */
  box-sizing: border-box;
}
#z_login {
  /* 弹性布局 让页面元素垂直+水平居中 */
  display: flex;
  justify-content: center;
  align-items: center;
  /* 让页面始终占浏览器可视区域总高度 */
  height: 100vh;
  /* 背景渐变色 */
  background: linear-gradient(#141e30, #243b55);
}
#z_login  .el-form-item__content{
    margin-left: 0px !important;
}
#z_login /deep/ .el-form-item__content{
    margin-left: 0px; 
}

.login {
  /* 弹性布局 让子元素称为弹性项目 */
  display: flex;
  /* 让弹性项目垂直排列 原理是改变弹性盒子的主轴方向 父元素就是弹性盒子 现在改变后的主轴方向是向下了 */
  flex-direction: column;
  /* 让弹性项目在交叉轴方向水平居中 现在主轴的方向是向下 交叉轴的方向是与主轴垂直 交叉轴的方向是向右 */
  align-items: center;
  width: 400px;
  padding: 40px;
  background-color: rgba(0, 0, 0, 0.2);
  box-shadow: 0 15px 25px rgba(0, 0, 0, 0.4);
}
.login h2 {
  color: #fff;
  margin-bottom: 30px;
}
.login .login_box {
  /* 相对定位 */
  position: relative;
  width: 100%;
}
/* ------------------------------------- */
.login .login_box .el-input__inner {
  /* 清除input框自带的边框和轮廓 */
  outline: none;
  border: none;
  width: 100%;
  padding: 10px 0;
  margin-bottom: 30px;
  color: #fff;
  font-size: 16px;
  border-bottom: 1px solid #fff;
  /* 背景颜色为透明色 */
  background-color: transparent;
}
/* -------------------------------------- */
.login .login_box .el-input .el-input__inner {
  /* 清除input框自带的边框和轮廓 */
  outline: none;
  border: none;
  width: 100%;
  padding: 10px 0;
  margin-bottom: 30px;
  color: #fff;
  font-size: 16px;
  border-bottom: 1px solid #fff;
  /* 背景颜色为透明色 */
  background-color: transparent;
}
.login .login_box .el-form-item__label,
.login .login_box .el-form-item__label {
  position: absolute;
  left: 0;
  /* padding: 10px 0; */
  color: #fff;
  /* 这个属性的默认值是auto 默认是这个元素可以被点击 但是如果我们写了none 就是这个元素不能被点击 , 就好像它可见但是不能用 可望而不可即 */
  /* 这个就是两者的区别 */
  pointer-events: none;
  /* 加个过渡 */
  transition: all 0.5s;
}
.login .login_box .passtie {
  bottom: 46px;
}
.login .login_box .usetie {
  top: 0;
}
/* :focus 选择器是当input获得焦点是触发的样式 + 是相邻兄弟选择器 去找与input相邻的兄弟label */
/* :valid 选择器是判断input框的内容是否合法,如果合法会执行下面的属性代码,不合法就不会执行,我们刚开始写布局的时候给input框写了required 我们删掉看对比 当没有required的话input框的值就会被认为一直合法,所以一直都是下方的样式 ,但是密码不会,密码框内的值为空,那么这句话局不合法,required不能为空 当我们给密码框写点东西的时候才会执行以下代码*/
/* .login .login_box input:focus + label,
.login .login_box input:valid + label {
  top: -20px;
  color: #03e9f4;
  font-size: 12px;
}
#nnn {
  top: -20px;
  color: #03e9f4;
  font-size: 12px;
} */
.login a {
  overflow: hidden;
  position: relative;
  padding: 10px 20px;
  color: #03e9f4;
  /* 取消a表现原有的下划线 */
  text-decoration: none;
  /* 同样加个过渡 */
  transition: all 0.5s;
}
.login a:hover {
  color: #fff;
  border-radius: 5px;
  background-color: #03e9f4;
  box-shadow: 0 0 5px #03e9f4, 0 0 25px #03e9f4, 0 0 50px #03e9f4,
    0 0 100px #03e9f4;
}
.login a span {
  position: absolute;
}
.login a span:first-child {
  top: 0;
  left: -100%;
  width: 100%;
  height: 2px;
  /* to right 就是往右边 下面的同理 */
  background: linear-gradient(to right, transparent, #03e9f4);
  /* 动画 名称 时长 linear是匀速运动 infinite是无限次运动 */
  animation: move1 1s linear infinite;
}
.login a span:nth-child(2) {
  right: 0;
  top: -100%;
  width: 2px;
  height: 100%;
  background: linear-gradient(transparent, #03e9f4);
  /* 这里多了个0.25s其实是延迟时间 */
  animation: move2 1s linear 0.25s infinite;
}
.login a span:nth-child(3) {
  right: -100%;
  bottom: 0;
  width: 100%;
  height: 2px;
  background: linear-gradient(to left, transparent, #03e9f4);
  animation: move3 1s linear 0.5s infinite;
}
.login a span:last-child {
  left: 0;
  bottom: -100%;
  width: 2px;
  height: 100%;
  background: linear-gradient(#03e9f4, transparent);
  animation: move4 1s linear 0.75s infinite;
}
.el-input__prefix,
.el-input__suffix {
  top: -7px;
}
/* 写一下动画 再坚持一下 视频马上就完了 */
@keyframes move1 {
  0% {
    left: -100%;
  }
  50%,
  100% {
    left: 100%;
  }
}
@keyframes move2 {
  0% {
    top: -100%;
  }
  50%,
  100% {
    top: 100%;
  }
}
@keyframes move3 {
  0% {
    right: -100%;
  }
  50%,
  100% {
    right: 100%;
  }
}
@keyframes move4 {
  0% {
    bottom: -100%;
  }
  50%,
  100% {
    bottom: 100%;
  }
}
</style>