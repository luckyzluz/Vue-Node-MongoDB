<template>
    <div id="z_admin">
z_admin
<router-view></router-view>
    </div>
</template>
<script>
export default {
    
}
</script>