import Vue from 'vue'
import VueRouter from 'vue-router'
import store from '@/store'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Zblog',
    component: ()=>import('../views/z_home'),
    meta:{
      title:'zblog博客',
      znav:'首页',
      iconfont: 'icon-home'
    }
  },
  {
    path: '/z_article',
    name: 'Zarticle',
    component: ()=>import('../views/z_article'),
    meta:{
      title:'文章',
      znav:'文章',
      iconfont: 'icon-paper'
    }
  },
  {
    path: '/z_login',
    name: 'Zlogin',
    component: ()=>import('../views/z_login'),
    meta:{
      title:'登录',
      znav:'登录',
      iconfont: 'icon-user'
    }
  },
  {
    path: '/z_admin',
    name: 'Zadmin',
    component: ()=>import('../views/admin/z_admin'),
    meta:{
      title:'后台管理中心 - 安全第一请勿泄露后台地址 - Copyright by Zblog后台管理系统',
      znav:'后台',
      needLogin: true
    },
    children:[
      {
        path: 'dashboard',
        component: () => import('@/views/admin/dashboard/index'),
        name: 'Dashboard',
        meta: { title: 'Dashboard', icon: 'dashboard', affix: true }
      }
    ]
  },
  {
    path: '/404',
    name: '404',
    component: ()=>import('../views/404'),
    meta:{
      title:'页面没了',
      znav:'404'
    }
  }
]

const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes
})
router.beforeEach((to, from, next) => {
  let title = 'blog'
  if (to.matched.length === 0) { // 如果未匹配到路由

    next('/404') 

  } else {
    if (to.meta.params){
      title = `${to.meta.title}:${to.params[to.meta.params] || ''} - ${title}`
  }else {
      title = `${to.meta.title} - ${title}`
  }
  document.title = title
  if (to.path !== from.path) {
      store.dispatch('setLoading', true);
  }
  // console.log(to.meta.needLogin);
  // admin后台是否已登录
  if (to.meta.needLogin) {
    if (localStorage.getItem('token')) {
      next()
    } else {
      next({
        name: 'Zlogin',
        query: {redirect: to.fullPath}
      })
    }
  }else{
    next();
  }

  }
})
router.afterEach((to, from) => {
  // 最多延迟 关闭 loading
  setTimeout(() => {
      store.dispatch('setLoading', false);
  }, 1500)
})
export default router
