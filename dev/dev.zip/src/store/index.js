import Vue from 'vue'
import Vuex from 'vuex'
import getters from './getters'

Vue.use(Vuex)

// https://webpack.js.org/guides/dependency-management/#requirecontext
// const modulesFiles = require.context('./modules', true, /\.js$/)

// // you do not need `import app from './modules/app'`
// // it will auto require all vuex module from modules file
// const modules = modulesFiles.keys().reduce((modules, modulePath) => {
//   // set './app.js' => 'app'
//   const moduleName = modulePath.replace(/^\.\/(.*)\.\w+$/, '$1')
//   const value = modulesFiles(modulePath)
//   modules[moduleName] = value.default
//   return modules
// }, {})

export default new Vuex.Store({
  state: {
    pageInit: false,
    // 记录有几个ajax请求正在执行中
    ajaxCount: 0,
    isLoading:false,
    loading: false
  },
  mutations: {
    SET_LOADING: (state, v) => {
      state.isLoading = v;
  }
  },
  actions: {
    setLoading: ({commit}, v) => {
      commit('SET_LOADING', v);
  }
  },
  modules: {
  },
  getters:{
    isLoading: state => state.isLoading,
  }
})
